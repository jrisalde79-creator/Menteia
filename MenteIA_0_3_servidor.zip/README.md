# MenteIA 0.3 — servidor

Backend de prueba para conectar la app MenteIA con la API de OpenAI.

Variable de entorno necesaria:
OPENAI_API_KEY

Nunca subas la clave a GitHub.
